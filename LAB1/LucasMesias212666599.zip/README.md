Para ejecutar el código, se descomprime el archivo zip, ya sea usando click derecho y la
opción de extraer, o con el comando ‘unzip LucasMesias212666599’, luego se abre una
terminal dentro de la carpeta recién extraída, se usa el comando ‘make’ seguido de la prueba
que se quiera ejecutar, finalmente se ejecuta el programa con el comando correspondiente
(./’testDeseada’).
• make test (Prueba principal)
• make testAVL
• make testFileReader
• make testNode
• make testOperation
• make testState
Para ejecutar la prueba principal, el archivo de lectura con el problema debe estar en la
carpeta principal que contiene el código fuente.