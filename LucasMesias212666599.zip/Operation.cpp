#include "Operation.h"

Operation::Operation()
{
    this->rightSideCount = 0;
    this->result = 0;
}

Operation::~Operation()
{
}
